# Global Market Analyzer

A browser-first market scanner for a configurable global equity watchlist. It is designed as a research aid, not an automated trading system.

## What it does

- Scans a configurable list of US, European and Polish tickers using Yahoo Finance daily OHLCV data.
- Calculates RSI(14), MACD, SMA20/50/200, 5-day and 20-day returns, relative volume and 20-day volatility.
- Produces a transparent technical/momentum score (0-100) and a watchlist ranking.
- Has a separate earnings mode using Finnhub's earnings calendar when `FINNHUB_API_KEY` is configured.
- Builds CSV and HTML reports on a GitHub Actions schedule.
- Includes a Streamlit browser dashboard. No local Python installation is required if deployed with Streamlit Community Cloud.

## Important data limitations

- Yahoo Finance data is unofficial and may be delayed, incomplete, adjusted, rate-limited or unavailable for some exchanges/tickers.
- Finnhub earnings dates require an API key and may have plan limits. The earnings calendar is not guaranteed complete.
- The included universe is a starter watchlist, **not every listed company worldwide**. Add/remove tickers in `config/watchlist.csv`.
- Ticker availability on XTB is not guaranteed. Verify the exact instrument and whether it is a real share/OMI or CFD in XTB before trading.
- This tool does not send orders, connect to XTB, or provide personalized investment advice. Scores are screening signals only.

## Quick start without installing Python

1. Create a new GitHub repository, e.g. `global-market-analyzer`.
2. Upload the contents of this ZIP to the repository (not the ZIP file itself).
3. In GitHub, open **Settings → Secrets and variables → Actions → New repository secret**.
   - Name: `FINNHUB_API_KEY`
   - Value: your Finnhub API key (optional; earnings mode has reduced functionality without it).
4. Open **Actions** and enable workflows if GitHub asks.
5. Open **Settings → Pages** and set source to **GitHub Actions**. The daily workflow publishes a static HTML report.
6. For the interactive dashboard, open https://share.streamlit.io/, connect GitHub, choose this repository and `app.py`. Streamlit Community Cloud hosts the app; no Python installation on your computer is needed.

## Manual workflow

In GitHub → Actions → `Daily global market scan` → `Run workflow`.

The workflow runs automatically Monday-Friday at 21:30 UTC. It writes `docs/index.html`, CSVs and a timestamped report. GitHub Pages serves `docs/`.

## Local run (optional)

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Configuration

Edit `config/watchlist.csv`. Yahoo Finance tickers use exchange suffixes, e.g.:
- US: `NVDA`, `MSFT`
- Poland: `PKN.WA`, `KGH.WA`, `PKO.WA`
- Germany: `SAP.DE`, `SIE.DE`
- France: `MC.PA`, `OR.PA`
- UK: `SHEL.L`, `AZN.L`

Suffix conventions can change and not every symbol is supported by Yahoo Finance.

## Scoring model

- Trend and moving-average structure: 25 points
- Momentum / RSI / MACD: 25 points
- Relative volume: 15 points
- Short-term price strength: 20 points
- Volatility / risk adjustment: 15 points

The earnings list is ranked separately by proximity to the report date and recent volatility. A high score does not mean a stock will rise. Earnings can cause gaps through stop-loss levels.
