import sys
from pathlib import Path
from datetime import date, timedelta
import pandas as pd
import streamlit as st
import plotly.express as px

sys.path.insert(0, str(Path(__file__).resolve().parent))
from src.analyzer import load_watchlist, scan_watchlist, get_earnings_calendar

st.set_page_config(page_title="Global Market Analyzer", page_icon="📈", layout="wide")
st.title("🌍 Global Market Analyzer")
st.caption("Global watchlist scanner · technical momentum · earnings calendar · research only")

with st.sidebar:
    st.header("Ustawienia")
    mode = st.radio("Tryb", ["Ranking rynku", "Wyniki spółek", "Oba"])
    st.caption("Dane cenowe: Yahoo Finance. Kalendarz wyników: Finnhub (wymaga klucza API).")
    if st.button("Odśwież analizę", type="primary"):
        st.cache_data.clear()
        st.rerun()

@st.cache_data(ttl=900, show_spinner=False)
def load_scan():
    return scan_watchlist()

@st.cache_data(ttl=3600, show_spinner=False)
def load_earnings():
    return get_earnings_calendar(date.today(), date.today() + timedelta(days=14))

if mode in ["Ranking rynku", "Oba"]:
    st.subheader("Ranking techniczny")
    with st.spinner("Pobieram dane i obliczam wskaźniki…"):
        data = load_scan()
    if not data.empty:
        ok = data[data["status"] == "ok"].copy()
        bad = data[data["status"] != "ok"]
        if not ok.empty:
            ok = ok.sort_values("score", ascending=False)
            c1,c2,c3 = st.columns(3)
            c1.metric("Przeanalizowane spółki", len(ok))
            c2.metric("Najwyższy wynik", int(ok["score"].max()) if len(ok) else "—")
            c3.metric("Data danych", str(ok["as_of"].max()))
            st.dataframe(ok, use_container_width=True, hide_index=True,
                         column_config={"score": st.column_config.ProgressColumn("Score", min_value=0, max_value=100)})
            fig = px.bar(ok.head(15).sort_values("score"), x="score", y="symbol", orientation="h",
                         title="15 najwyżej ocenionych spółek")
            st.plotly_chart(fig, use_container_width=True)
            st.download_button("Pobierz ranking CSV", ok.to_csv(index=False).encode("utf-8"),
                               "global_market_ranking.csv", "text/csv")
        if not bad.empty:
            with st.expander(f"Spółki bez poprawnych danych ({len(bad)})"):
                st.dataframe(bad, use_container_width=True, hide_index=True)
    st.info("Wynik 0–100 jest heurystycznym rankingiem technicznym, a nie prawdopodobieństwem wzrostu ani rekomendacją kupna.")

if mode in ["Wyniki spółek", "Oba"]:
    st.subheader("Kalendarz wyników – najbliższe 14 dni")
    try:
        earnings = load_earnings()
        if earnings.empty:
            st.warning("Brak danych. Dodaj FINNHUB_API_KEY w GitHub Secrets / środowisku aplikacji, aby włączyć kalendarz Finnhub.")
        else:
            st.dataframe(earnings, use_container_width=True, hide_index=True)
            st.download_button("Pobierz kalendarz CSV", earnings.to_csv(index=False).encode("utf-8"),
                               "earnings_calendar.csv", "text/csv")
    except Exception as e:
        st.error(f"Nie udało się pobrać kalendarza wyników: {e}")

st.divider()
st.caption("To narzędzie nie łączy się z XTB i nie składa zleceń. Sprawdź ticker, walutę, spread, instrument (akcja/OMI lub CFD) i aktualność danych przed decyzją.")
