from pathlib import Path
import sys
from datetime import datetime, timezone, date, timedelta
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from src.analyzer import scan_watchlist, get_earnings_calendar

DOCS = ROOT / "docs"
DOCS.mkdir(exist_ok=True)

scan = scan_watchlist()
ok = scan[scan.get("status", pd.Series(dtype=str)) == "ok"].sort_values("score", ascending=False)
scan.to_csv(DOCS / "market_scan.csv", index=False)
try:
    earnings = get_earnings_calendar(date.today(), date.today() + timedelta(days=14))
except Exception as exc:
    earnings = pd.DataFrame()
    print(f"Earnings fetch failed: {exc}")
earnings.to_csv(DOCS / "earnings_calendar.csv", index=False)

stamp = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
def table(df):
    if df.empty: return "<p>Brak danych.</p>"
    return df.to_html(index=False, border=0, classes="data")
top = ok.head(30)
html = f"""<!doctype html><html lang="pl"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Global Market Analyzer</title><style>
body{{font-family:system-ui;max-width:1200px;margin:32px auto;padding:0 16px;background:#0b1220;color:#e8eef8}}
h1,h2{{color:#fff}} .muted{{color:#aab6c8}} table{{border-collapse:collapse;width:100%;background:#131e30}}
th,td{{padding:9px;border-bottom:1px solid #26354c;text-align:left;font-size:14px}} th{{background:#1c2b42;position:sticky;top:0}}
a{{color:#8bc5ff}} .wrap{{overflow-x:auto}} .note{{padding:14px;background:#17253a;border-radius:10px}}
</style><h1>🌍 Global Market Analyzer</h1><p class="muted">Aktualizacja: {stamp}</p>
<div class="note">Ranking techniczny 0–100 to heurystyka, nie prawdopodobieństwo wzrostu ani rekomendacja inwestycyjna. Dane mogą być opóźnione lub niekompletne.</div>
<h2>Najwyższe wyniki</h2><div class="wrap">{table(top)}</div>
<h2>Kalendarz wyników (Finnhub)</h2><div class="wrap">{table(earnings)}</div>
<p><a href="market_scan.csv">Pobierz pełny ranking CSV</a> · <a href="earnings_calendar.csv">Pobierz kalendarz CSV</a></p>
<p class="muted">XTB availability is not verified. Confirm instrument type, currency, spread and availability in XTB before trading.</p>
</html>"""
(DOCS / "index.html").write_text(html, encoding="utf-8")
print(f"Generated report for {len(ok)} tickers.")
