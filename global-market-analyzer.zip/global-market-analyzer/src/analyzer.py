from __future__ import annotations
import os
from datetime import date, timedelta
from pathlib import Path
import numpy as np
import pandas as pd
import requests
import yfinance as yf

ROOT = Path(__file__).resolve().parents[1]
WATCHLIST = ROOT / "config" / "watchlist.csv"

def load_watchlist() -> pd.DataFrame:
    return pd.read_csv(WATCHLIST).fillna("")

def _rsi(series: pd.Series, period: int = 14) -> pd.Series:
    delta = series.diff()
    gain = delta.clip(lower=0).ewm(alpha=1/period, adjust=False).mean()
    loss = (-delta.clip(upper=0)).ewm(alpha=1/period, adjust=False).mean()
    rs = gain / loss.replace(0, np.nan)
    return 100 - (100 / (1 + rs))

def analyze_symbol(symbol: str, name: str = "", market: str = "") -> dict:
    hist = yf.download(symbol, period="1y", interval="1d", auto_adjust=True,
                       progress=False, threads=False)
    if hist is None or hist.empty or len(hist) < 60:
        return {"symbol": symbol, "name": name, "market": market, "status": "no_data"}
    if isinstance(hist.columns, pd.MultiIndex):
        hist.columns = hist.columns.get_level_values(0)
    close = hist["Close"].dropna()
    volume = hist["Volume"].reindex(close.index).fillna(0)
    if len(close) < 60:
        return {"symbol": symbol, "name": name, "market": market, "status": "insufficient_data"}

    sma20 = close.rolling(20).mean()
    sma50 = close.rolling(50).mean()
    sma200 = close.rolling(200).mean()
    rsi = _rsi(close)
    ema12, ema26 = close.ewm(span=12, adjust=False).mean(), close.ewm(span=26, adjust=False).mean()
    macd = ema12 - ema26
    signal = macd.ewm(span=9, adjust=False).mean()
    ret5 = (close.iloc[-1] / close.iloc[-6] - 1) * 100 if len(close) >= 6 else np.nan
    ret20 = (close.iloc[-1] / close.iloc[-21] - 1) * 100 if len(close) >= 21 else np.nan
    avgvol = volume.rolling(20).mean().iloc[-1]
    relvol = volume.iloc[-1] / avgvol if avgvol and avgvol > 0 else np.nan
    vol20 = close.pct_change().rolling(20).std().iloc[-1] * np.sqrt(252) * 100

    # Transparent heuristic score, deliberately not a probability.
    trend = 0
    trend += 10 if close.iloc[-1] > sma20.iloc[-1] else 0
    trend += 8 if sma20.iloc[-1] > sma50.iloc[-1] else 0
    trend += 7 if len(close) >= 200 and close.iloc[-1] > sma200.iloc[-1] else 3 if len(close) < 200 else 0

    mom = 0
    rv = float(rsi.iloc[-1]) if pd.notna(rsi.iloc[-1]) else 50
    if 50 <= rv <= 68: mom += 10
    elif 42 <= rv < 50: mom += 5
    elif 68 < rv <= 75: mom += 4
    if macd.iloc[-1] > signal.iloc[-1]: mom += 10
    if macd.iloc[-1] > macd.iloc[-2]: mom += 5

    volume_score = 0
    if pd.notna(relvol):
        volume_score = 15 if relvol >= 1.8 else 11 if relvol >= 1.3 else 7 if relvol >= 0.9 else 3

    strength = 0
    strength += 10 if ret5 > 0 else 0
    strength += 10 if ret20 > 0 else 0
    risk = 15
    if pd.notna(vol20):
        risk = 15 if vol20 < 35 else 11 if vol20 < 55 else 7 if vol20 < 80 else 3
    score = int(max(0, min(100, trend + mom + volume_score + strength + risk)))

    return {
        "symbol": symbol, "name": name, "market": market, "status": "ok",
        "price": round(float(close.iloc[-1]), 4),
        "change_1d_pct": round(float(close.pct_change().iloc[-1] * 100), 2),
        "return_5d_pct": round(float(ret5), 2), "return_20d_pct": round(float(ret20), 2),
        "rsi14": round(rv, 1), "relative_volume": round(float(relvol), 2) if pd.notna(relvol) else None,
        "volatility_annual_pct": round(float(vol20), 1) if pd.notna(vol20) else None,
        "above_sma20": bool(close.iloc[-1] > sma20.iloc[-1]),
        "above_sma50": bool(close.iloc[-1] > sma50.iloc[-1]),
        "above_sma200": bool(close.iloc[-1] > sma200.iloc[-1]) if len(close) >= 200 else None,
        "macd_bullish": bool(macd.iloc[-1] > signal.iloc[-1]),
        "score": score, "as_of": str(close.index[-1].date())
    }

def scan_watchlist(watchlist: pd.DataFrame | None = None) -> pd.DataFrame:
    wl = watchlist if watchlist is not None else load_watchlist()
    rows = []
    for row in wl.to_dict("records"):
        try:
            rows.append(analyze_symbol(str(row["symbol"]), str(row.get("name","")), str(row.get("market",""))))
        except Exception as exc:
            rows.append({"symbol": row.get("symbol"), "name": row.get("name"), "market": row.get("market"),
                         "status": "error", "error": str(exc)[:180]})
    return pd.DataFrame(rows)

def get_earnings_calendar(from_date: date | None = None, to_date: date | None = None) -> pd.DataFrame:
    token = os.getenv("FINNHUB_API_KEY", "")
    if not token:
        return pd.DataFrame(columns=["date", "symbol", "hour", "eps_estimate", "revenue_estimate", "source"])
    start = from_date or date.today()
    end = to_date or (start + timedelta(days=7))
    url = "https://finnhub.io/api/v1/calendar/earnings"
    response = requests.get(url, params={"from": start.isoformat(), "to": end.isoformat(), "token": token}, timeout=20)
    response.raise_for_status()
    rows = response.json().get("earningsCalendar", [])
    df = pd.DataFrame(rows)
    if df.empty:
        return df
    keep = [c for c in ["date", "symbol", "hour", "epsEstimate", "revenueEstimate", "epsActual", "revenueActual"] if c in df.columns]
    df = df[keep].copy()
    df = df.rename(columns={"epsEstimate":"eps_estimate","revenueEstimate":"revenue_estimate",
                            "epsActual":"eps_actual","revenueActual":"revenue_actual"})
    df["source"] = "Finnhub"
    return df.sort_values(["date", "symbol"])
